def generate_diagram(context_text: str, diagram_type: str = "architecture"):
    return {"diagram_url": f"https://placeholder-diagrams.com/{diagram_type}.png"}