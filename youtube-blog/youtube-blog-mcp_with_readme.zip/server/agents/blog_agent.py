from openai import OpenAI
client = OpenAI()
def generate_blog(clean_transcript: str, tone: str = "educational"):
    prompt = f"Create a detailed blog in {tone} tone from this transcript:\n{clean_transcript}"
    response = client.chat.completions.create(model="gpt-4-turbo", messages=[{"role": "user", "content": prompt}])
    return {"blog_markdown": response.choices[0].message.content}