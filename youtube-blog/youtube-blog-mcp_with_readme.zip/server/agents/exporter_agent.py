from docx import Document
from reportlab.pdfgen import canvas
def export_blog(blog_markdown: str, include_images: bool = True):
    docx_path = "blog_output.docx"
    pdf_path = "blog_output.pdf"
    doc = Document()
    doc.add_paragraph(blog_markdown)
    doc.save(docx_path)
    c = canvas.Canvas(pdf_path)
    c.drawString(50, 800, blog_markdown[:1000])
    c.save()
    return {"docx_url": docx_path, "pdf_url": pdf_path}