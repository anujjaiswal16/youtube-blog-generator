from fastapi import FastAPI, Request
from agents.transcript_agent import get_transcript
from agents.blog_agent import generate_blog
from agents.visual_agent import generate_diagram
from agents.exporter_agent import export_blog
import json, os

app = FastAPI(title="YouTube Blog MCP Server")

TOOLS = {
    "TranscriptAgent.get_transcript": get_transcript,
    "BlogAgent.generate_blog": generate_blog,
    "VisualAgent.generate_diagram": generate_diagram,
    "ExporterAgent.export_blog": export_blog
}

@app.get("/tools")
def list_tools():
    manifests = []
    for file in os.listdir("server/manifests"):
        if file.endswith(".json") and file != "server.manifest.json":
            with open(os.path.join("server/manifests", file)) as f:
                manifests.append(json.load(f))
    return manifests

@app.post("/jsonrpc")
async def jsonrpc(req: Request):
    payload = await req.json()
    method = payload.get("method")
    params = payload.get("params", {})
    _id = payload.get("id", 1)

    if method == "list_tools":
        return {"jsonrpc": "2.0", "result": list_tools(), "id": _id}

    if method == "call_tool":
        tool = params.get("tool")
        inputs = params.get("inputs", {})
        func = TOOLS.get(tool)
        if not func:
            return {"jsonrpc": "2.0", "error": {"message": "Tool not found"}, "id": _id}
        try:
            result = func(**inputs)
            return {"jsonrpc": "2.0", "result": result, "id": _id}
        except Exception as e:
            return {"jsonrpc": "2.0", "error": {"message": str(e)}, "id": _id}