import json, requests
from openai import OpenAI
client = OpenAI()
class MCPClient:
    def __init__(self, server_url):
        self.server_url = server_url
    def list_tools(self):
        payload = {"jsonrpc": "2.0", "id": 1, "method": "list_tools"}
        return requests.post(f"{self.server_url}/jsonrpc", json=payload).json()["result"]
    def call_tool(self, tool, inputs):
        payload = {"jsonrpc": "2.0", "id": 1, "method": "call_tool", "params": {"tool": tool, "inputs": inputs}}
        return requests.post(f"{self.server_url}/jsonrpc", json=payload).json()["result"]
    def plan_and_execute(self, goal):
        tools = self.list_tools()
        plan_prompt = f"You are an AI planner. Goal: {goal}. Tools: {json.dumps(tools, indent=2)}"
        plan = client.chat.completions.create(model="gpt-4-turbo", messages=[{"role": "user", "content": plan_prompt}])
        steps = json.loads(plan.choices[0].message.content)["plan"]
        context = {}
        for step in steps:
            tool = step["tool"]
            inputs = {k: (context.get(v.replace('$prev.', ''), v) if isinstance(v, str) and v.startswith('$prev.') else v) for k, v in step["inputs"].items()}
            result = self.call_tool(tool, inputs)
            context.update(result)
        return context
if __name__ == "__main__":
    client = MCPClient("http://localhost:8000")
    goal = "Generate a blog post from a YouTube video: https://youtube.com/watch?v=abcd1234"
    print(client.plan_and_execute(goal))