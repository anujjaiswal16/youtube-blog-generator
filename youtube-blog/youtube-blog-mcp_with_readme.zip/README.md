# YouTube Blog MCP System

## 🧠 Overview
This project demonstrates an **Agentic AI workflow** that converts YouTube videos into structured blogs using an **MCP (Model Context Protocol)** architecture.

The system includes:
- Transcript extraction (via YouTube API)
- Blog generation (via OpenAI GPT)
- Diagram generation (stub for future use)
- Export to DOCX and PDF formats
- An MCP client for orchestration and planning

---

## ⚙️ Setup Instructions

### 1. Clone or Unzip the Project
```bash
unzip youtube-blog-mcp.zip
cd youtube-blog-mcp
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Start the MCP Server
```bash
cd server
uvicorn server:app --port 8000 --reload
```

The server exposes MCP-compatible endpoints at:
```
http://localhost:8000/jsonrpc
```

### 4. Run the MCP Client
```bash
cd ../client
python mcp_client.py
```

This triggers an AI-planned workflow that will:
1. Fetch a YouTube transcript  
2. Generate a blog from the transcript  
3. (Optionally) generate diagrams  
4. Export the final blog to both DOCX and PDF  

---

## 📂 Project Structure

```
youtube-blog-mcp/
├── server/
│   ├── server.py                  # MCP Server and JSON-RPC API
│   ├── agents/                    # AI/Tool Agents
│   │   ├── transcript_agent.py
│   │   ├── blog_agent.py
│   │   ├── visual_agent.py
│   │   └── exporter_agent.py
│   └── manifests/                 # MCP Manifests (to integrate with other MCP clients)
├── client/
│   └── mcp_client.py              # MCP Client that orchestrates workflow
└── requirements.txt
```

---

## 🧩 Extending the System

You can easily extend the system by adding new agents:
- **SummarizerAgent** — summarize blogs or transcripts.
- **SEOAgent** — optimize blog for search engines.
- **PublisherAgent** — auto-publish to WordPress or Medium.

Each new agent requires a corresponding manifest JSON file in `server/manifests/`.

---

## 🧠 LLM Integration

The `blog_agent` uses the OpenAI GPT model for generating high-quality blogs.
You can customize the prompt or tone by modifying this function in `server/agents/blog_agent.py`.

---

## 🧭 Example Goal

```
Goal: "Generate a blog post from a YouTube video: https://youtube.com/watch?v=dQw4w9WgXcQ"
```

The MCP client will automatically plan the tool usage:
1. TranscriptAgent.get_transcript
2. BlogAgent.generate_blog
3. ExporterAgent.export_blog

---

## 🪄 Author
**Anuj Kumar Jaiswal**  
Senior Customer Architect | Elastic | GenAI Enthusiast
